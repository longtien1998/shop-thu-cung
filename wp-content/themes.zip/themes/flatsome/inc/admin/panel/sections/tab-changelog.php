<?php
/**
 * Theme Change log
 */
?>
<div id="tab-changelog" class="coltwo-col panel flatsome-panel">
<div class="inner-panel">
<pre style="padding:30px; overflow: auto;">
<?php require get_template_directory() . '/changes.txt'; ?>
</pre>
</div>
</div>
