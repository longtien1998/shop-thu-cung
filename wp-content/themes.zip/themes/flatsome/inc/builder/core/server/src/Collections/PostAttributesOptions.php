<?php

namespace UxBuilder\Collections;

class PostAttributesOptions extends Collection {

}
